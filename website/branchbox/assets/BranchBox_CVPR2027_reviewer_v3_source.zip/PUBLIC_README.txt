Public research preprint, November 2026.
Compile public_main.tex and public_supplementary.tex for the named public PDFs.
Main.tex and supplementary.tex remain the anonymous review versions.
Qinzhen Ma, Harry Yang, and Changsheng Lu contributed equally. Xiaogang Xu
follows these three equal-contributing authors. No corresponding-author role
or conference acceptance is designated. All share the same manuscript body.
For anonymous review, use the separate anonymous source package instead.
