BranchBox reviewer revision v3, 2026-11-01

Main.tex and supplementary.tex are anonymous review versions.
They use the unchanged official CVPR style and do not include author identity.
Compile with Tectonic 0.17.0, or pdflatex/bibtex with the normal repeated passes.

No new training or robot evaluation was performed for this revision.
Retrospective focus: 2 models, 4 two-object tasks, 80 shared scenes.
Success: 73/160 to 91/160, +11.25 percentage points / +24.6575% relative.
The unadjusted scene-clustered 95% interval is [1.875,20.625] pp.
Indices are paired across both models and all arms. The source explains the
retrospective selection, single-seed scope, and complete broader study.

Reproduce focused statistics (NumPy required):
  python analysis/reproduce.py
This validates all 720 records in episodes.csv and writes
analysis/reproduced_statistics.json. It must match scene_clustered_statistics.json.
The CSV contains binary evaluation results for the two models on all six tasks;
the analysis script selects task IDs 0,3,4,5 in a fixed order.

Figures are included as vector PDF/TikZ. No plotting dependency is required to
compile the manuscript. Exact training optimizer/checkpoint revision receipts
were unavailable locally and are not invented in this manuscript source.

Do not upload author review reports, local build logs, or publication files as
part of the anonymous submission.
