"""Recount the complete four-scene development panel; no simulator or model call."""
import csv
import hashlib
import json
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    metadata = json.loads((root / "anonymous_agent_dev4_metadata.json").read_text())
    path = root / metadata["episode_csv"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == metadata["episode_csv_sha256"]
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    keys = [(int(row["task_id"]), int(row["initial_state_id"])) for row in rows]
    assert len(keys) == len(set(keys)) == 4
    assert set(keys) == {tuple(key) for key in metadata["planned_keys"]}
    for row in rows:
        assert row["outcome_status"] == "complete"
        assert row["success"] in {"0", "1"}
        assert 0 <= int(row["robot_actions"]) <= int(row["max_robot_actions"]) == 520
        assert int(row["episode_seed"]) == (
            1000003 + int(row["task_id"]) * 1009 + int(row["initial_state_id"])
        ) % 2147483648
    result = {
        "planned": len(keys),
        "completed_valid": len(rows),
        "successes": sum(int(row["success"]) for row in rows),
        "unknown": 0,
        "robot_actions": sum(int(row["robot_actions"]) for row in rows),
        "vlm_calls": sum(int(row["vlm_calls"]) for row in rows),
    }
    assert all(value == metadata["expected_totals"][key] for key, value in result.items())
    result["scope"] = metadata["analysis_scope"]
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
