BranchBox manuscript and outcome-level statistical reproduction

The main paper emphasizes the original stage/target recipe. Its focused,
retrospectively selected analysis covers two models and four tasks on 80 shared
scenes. Matched action-only training solves 73/160 model-scene outcomes;
self-prompted BranchBox solves 91/160, and ordinary inputs solve 89/160.
The first contrast is +11.25 percentage points or +24.6575% relative,
rounded to +11.3 points and +24.7%. This is exploratory, with one training seed.
The supplement retains the complete broader original scope and all memory
results, including unsuccessful variants and protocol limitations.

Separate memory extensions (do not pool their counts):
  Cache: 40 pairs, off 19/40 versus hold1 14/40. Both arms use an alignment
    gate absent from original PS.
  Full-weight memory: final 6,000 updates, 20 triples; original 13/20,
    memory 12/20, same-weight joint state/anchor reset 11/20.
  Revised memory: validation-selected LoRA a@100, 180 quadruples; original
    118/180, memory 103/180, state-only reset 107/180, joint reset 113/180.
    Primary memory-minus-state-reset: -2.2 points, 95% CI [-8.9,+4.4].
None establishes an added memory gain under its tested conditions; these
results do not establish that recurrent memory is generally ineffective.
Training-plan changes, selection, diagnostics and all task increases and
decreases are disclosed. Panels overlap with previous development scenes.

Statistical reproduction (Python 3 and NumPy, no GPU/model/simulator needed):
  python analysis/reproduce.py
  python analysis/memory/reproduce_memory.py --reference analysis/memory/analysis.json
  python analysis/memory_cache/reproduce_memory_cache.py
  python analysis/memory_redo/reproduce.py
Original CSV: all 720 outcomes for two models on six LIBERO tasks.
Memory subdirectories: all 20, 40 and 180 paired outcome rows respectively.
These scripts reproduce statistics and do not rerun training or evaluation.

Build with Tectonic 0.17.0:
  tectonic --keep-logs main.tex
  tectonic --keep-logs supplementary.tex
Or use pdflatex, bibtex, pdflatex, pdflatex on each entry. Repeat LaTeX for any
remaining cross-reference/line-number rerun warnings. The official 2027 style
and bibliography style are unchanged. Both documents use 10pt, two-column,
US Letter format. The LLM Usage Statement follows the main text.

Anonymous and public source packages are separate. Only the anonymous package
is suitable for double-blind submission. The public package has author names.
Build logs, private paths, weights and training data are excluded. Reachable
manuscript sources, scientific figures and anonymous reproduction files are
included; PACKAGE_MANIFEST.json records exact file hashes.

Supplement-only update, 2026-11-03:
  Completed MotorMind/Gemma-3-4B-IT development panel: all four planned scenes,
  zero successes, 1,857 environment actions, 128 model requests. Extra RGB/depth/
  calibration and a replacement action generator make this a separate feasibility
  study, not an isolated BranchBox ablation. Reused development scenes; no general
  performance claim. No incomplete panel or selected completed subset is pooled.
  python analysis/agent_development/anonymous_agent_dev4_reproduce.py
  This script recounts archived outcomes only; it starts no model or simulator.
  Original outcome data and detailed memory appendix are unchanged. The main
  manuscript now condenses peripheral outcomes and clarifies the training design
  and the two deployment modes; no experimental numbers have changed.
