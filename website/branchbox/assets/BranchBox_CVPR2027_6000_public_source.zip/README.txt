BranchBox manuscript and reproducible statistics

The manuscript separates two studies:
1. The original two-model, four-task focused analysis, reconstructed from
   existing rollouts. It reports 73/160 versus 91/160 successes: 11.25 percentage
   points and 24.6575% relative change, rounded to 11.3 and 24.7%, respectively.
2. A separate full-weight MemBodied adaptation of the existing X-VLA-P,
   with 6,000 total updates and a fixed 20-scene, three-condition development
   panel. The existing X-VLA-P baseline is not the original action-only N0.

Training uses one master seed. The 6,000 budget is a disclosed extension of
800 + 1,200 + 4,000 updates, decided during training before any new rollout. Only
the final 6,000 EMA is evaluated. History-reset uses identical trained weights
and clears both associative and initial-scene history at every query. The
original BranchBox stage filter and one-query prompt feedback remain enabled
in all three conditions; the reset concerns the added memory paths.

Reproduce the original focused analysis (Python and NumPy):
  python analysis/reproduce.py
Its 720-row input includes both models, all six evaluated LIBERO tasks and all
three original arms. The script uses paired common-scene bootstrap sampling.

Reproduce the separate complete memory panel:
  python analysis/memory/reproduce_memory.py --reference analysis/memory/analysis.json
The release contains all 20 paired rows. The script rejects missing or duplicate
scenes and recomputes counts, intervals, exact McNemar tests and Holm adjustment.
It checks the statistics, not simulator execution or model-weight provenance;
those are covered by the separate experiment audit and deployment artifacts.

Build with a standard TeX distribution:
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  bibtex main
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex
  bibtex supplementary
  pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex
  pdflatex -interaction=nonstopmode -halt-on-error supplementary.tex
Repeat LaTeX if cross-reference or line-number rerun warnings remain.

Alternatively, Tectonic 0.17.0 compiles main.tex and supplementary.tex.
The cvpr.sty and ieeenat_fullname.bst files match the official 2027 author kit.
T1 font encoding keeps the requested Times-family text under both engines.
Do not include build logs or temporary files in an anonymous submission.
The anonymous and named preprint packages are separate. The named version has
the requested author list and equal-contribution note; it is not the file for
double-blind submission. No conference acceptance is implied.
