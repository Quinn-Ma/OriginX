PaTH-VLA: Progress-and-Target Context for Long-Horizon Robot Policy Adaptation -- LaTeX source of the preprint

Build with pdfLaTeX and BibTeX, main paper first (the supplement reads main.aux for its references to the paper):
  pdflatex main; bibtex main; pdflatex main; pdflatex main; pdflatex main
  pdflatex supplementary; bibtex supplementary; pdflatex supplementary; pdflatex supplementary; pdflatex supplementary
The third pdflatex pass after bibtex fills in the back-references of the bibliographies.
Numbers in tables/*.tex are written by the analysis scripts released with the episode logs.
