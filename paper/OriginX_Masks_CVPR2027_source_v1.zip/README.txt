Object-Centric Mask Prompts for a Frozen Robot Policy: Pixel-Fidelity Verification and a Preregistered Null Result for Fine-Region Cues
Main document: main.tex (CVPR 2027 review mode, anonymous).
Build: bash build5.sh (pdflatex, bibtex, then pdflatex until no rerun request; TinyTeX/TeX Live 2026 was used).
figures/fig_architecture.tex is a TikZ figure; figures/*.png are unretouched H800 contact sheets.
