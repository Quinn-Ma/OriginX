Object-Centric Mask Prompts for a Frozen Robot Policy: Pixel-Fidelity Verification and Preregistered Null Results for Fine-Region and Mask Cues (v2, 2026-10-27: adds the completed mask-versus-point study run on the HKUST H100 cluster)
Main document: main.tex (CVPR 2027 review mode, anonymous).
Build: bash build5.sh (pdflatex, bibtex, then pdflatex until no rerun request; TinyTeX/TeX Live 2026 was used).
figures/fig_architecture.tex is a TikZ figure; figures/*.png are unretouched H800 contact sheets.
