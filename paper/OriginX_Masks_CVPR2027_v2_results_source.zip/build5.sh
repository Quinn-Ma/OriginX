#!/bin/bash
# exact CVPR chain, then repeat pdflatex until no rerun request (max 5 passes)
export PATH="$HOME/.local/bin:$PATH"
cd "$(dirname "$0")"
rm -f main.aux main.bbl main.blg main.brf main.out main.log main.toc
pdflatex -interaction=nonstopmode -halt-on-error main.tex > /dev/null || { grep -A3 '^!' main.log | head -20; exit 1; }
bibtex main > /dev/null
for i in 1 2 3 4; do
  pdflatex -interaction=nonstopmode -halt-on-error main.tex > /dev/null || { grep -A3 '^!' main.log | head -20; exit 1; }
  grep -q "Rerun to get\|rerun LaTeX\|Rerun LaTeX" main.log || break
done
grep -E "Output written|undefined|Overfull" main.log | head -10
